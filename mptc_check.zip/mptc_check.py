# MPTC_CHECK
# Este programa ejecuta MPTC a los ficheros indicados en la lista target
# y genera un fichero con el resultado de todas las pruebas.
# En pantalla indica si las pruebas se han superado o no.

import colorama
import datetime
import os
import subprocess
import time


def main():
    print("PRUEBA EJERCICIOS MPTC")

    result = f"mptc-check-{datetime.datetime.utcnow().strftime('%y%m%d-%H%M%S')}.txt"
    retardo = 5.0  # segundos
    if os.path.exists(result):
        confirma = input(
            "El fichero de resultados ya existe. Pulse S para sobreescribirlo: "
        )
    else:
        confirma = "S"
    if confirma == "S" or confirma == "s":
        if os.path.exists(result):
            command = f"del {result}"
            process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
            process.communicate()[0].strip()
        inicio = time.time()
        for i in range(len(target)):
            tiempo = (
                "{:02}".format(round(time.time() - inicio) // 3600)
                + ":"
                + "{:02}".format(round(time.time() - inicio) % 3600 // 60)
                + ":"
                + "{:02}".format(round(time.time() - inicio) % 60)
            )
            print(f"MPTC {i + 1} de {len(target)} - {target[i][2]} - {tiempo}", end="")
            # print(f"cd {i[0]}; mptc {i[1]} {i[2]} >> {result}; cd ..")
            p = target[i]
            file = p[1] + "\\" + p[2]
            if os.path.exists(file):
                command = f"cd {p[1]} & mptc {p[2]} {p[0]} >> ..\\{result} & cd .."
                process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
                process.communicate()[0].strip()
                time.sleep(retardo)
                with open(result, mode="r", encoding="latin-1") as fichero:
                    liner = fichero.readlines()
                    resultado = liner[len(liner) - 2]
                    if resultado.find("fallado") != -1:
                        print(f" - {colorama.Fore.RED}FALLO{colorama.Style.RESET_ALL}")
                    else:
                        print(f" - {colorama.Fore.GREEN}SUPERADO{colorama.Style.RESET_ALL}")
            else:
                print(
                    f"{colorama.Fore.RED}{file} no encontrada{colorama.Style.RESET_ALL}"
                )
        print("Prueba terminada")
    else:
        print("No se ha realizado ninguna prueba.")

target = [
    # Añadir una línea por cada programa a probar indicando en forma de cadenas
    # el número MPTC, el directorio del programa, el nombre del programa y, si queréis, un comentario
    # Cada línea tiene que ir entre corchetes y seguida de una coma, como esta:
    #["NÚMERO MPTC", "DIRECTORIO", "PROGRAMA.PY", "COMENTARIO"]
    ["11", "if-else-2", "p_11.py", ""]
]

if __name__ == "__main__":
    main()
